<!DOCTYPE html>
<html>
<head>
  <title> HOME </title>
  <meta charset="utf-8">
 <meta name="viewport" content="width=device-width, initial-scale=1">
 <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
 <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
 <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>

  </head>
  <body>
    <div class="row">
    <div class="col-md-6">
    <p> Student</p><br>
    <a href="./Student/Signup.php"> SIGN UP </a><br>
    <a href="./Student/login.php"> LOG IN </a><br>
  </div>
</div>

<div class="row">
<div class="col-md-6">
<br>
    <p> Alumni</p><br>
    <a href="./Alumni/SignUp.php"> SIGN UP </a><br>
    <a href="./Alumni/login.php"> LOG IN</a><br>
<br>
</div>
</div>
<div class="row">
<div class="col-md-6">
    <p> Company</p><br>
    <a href="./Company/SignUp.php"> SIGN UP </a><br>
    <a href="./Company/login.php"> LOG IN </a><br>
<br>
</div>
</div>
<div class="row">
<div class="col-md-6">
    <p> ADMIN</p><br>
    <a href="./Admin/login.php"> LOG IN </a><br>
</div>
</div>
    </body>

</html>
